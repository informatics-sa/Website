// lgrader.cpp
#include "atena.h"
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cassert>
#include <tuple>
#include <utility>
#include <set>
#include <array>
#include <iomanip>

using namespace std;

namespace Private { // https://victorlecomte.com/cp-geo.pdf

using float_type = long double;
const float_type inf = 1e100;
const float_type eps = 1e-9;
const float_type PI = acos((float_type)-1.0);
[[maybe_unused]] int sign(float_type x) { return (x > eps) - (x < -eps); }

namespace Vector {
  struct PT {
    float_type x, y;
    PT() { x = 0, y = 0; }
    PT(float_type x, float_type y) : x(x), y(y) {}
    PT(const PT &p) : x(p.x), y(p.y) {}
    PT operator+(const PT &a) const { return PT(x + a.x, y + a.y); }
    PT operator-(const PT &a) const { return PT(x - a.x, y - a.y); }
    PT operator*(const float_type a) const { return PT(x * a, y * a); }
    friend PT operator*(const float_type &a, const PT &b) { return PT(a * b.x, a * b.y); }
    PT operator/(const float_type a) const { return PT(x / a, y / a); }
    bool operator==(PT a) const { return sign(a.x - x) == 0 && sign(a.y - y) == 0; }
    bool operator!=(PT a) const { return !(*this == a); }
    float_type norm() { return sqrt(x * x + y * y); }
    float_type norm2() { return x * x + y * y; }
    float_type arg() { return atan2(y, x); }
    PT truncate(double r) { // returns a vector with norm r and having same direction
      double k = norm();
      if (!sign(k)) return *this;
        r /= k;
        return PT(x * r, y * r);
      }
  };

  [[maybe_unused]] istream &operator>>(istream &in, PT &p) { return in >> p.x >> p.y; }
  [[maybe_unused]] ostream &operator<<(ostream &out, PT &p) { return out << "(" << p.x << "," << p.y << ")"; }

  [[maybe_unused]] inline float_type dot(PT a, PT b) { return a.x * b.x + a.y * b.y; }
  [[maybe_unused]] inline float_type dist2(PT a, PT b) { return dot(a - b, a - b); }
  [[maybe_unused]] inline float_type dist(PT a, PT b) { return sqrt(dot(a - b, a - b)); }
  [[maybe_unused]] inline float_type cross(PT a, PT b) { return a.x * b.y - a.y * b.x; }
  [[maybe_unused]] inline float_type cross2(PT a, PT b, PT c) { return cross(b - a, c - a); }
  [[maybe_unused]] inline int orientation(PT a, PT b, PT c) { return sign(cross(b - a, c - a)); }
  [[maybe_unused]] PT perp(PT a) { return PT(-a.y, a.x); }
  [[maybe_unused]] PT rotateccw90(PT a) { return PT(-a.y, a.x); }
  [[maybe_unused]] PT rotatecw90(PT a) { return PT(a.y, -a.x); }
  [[maybe_unused]] PT rotateccw(PT a, float_type t) { return PT(a.x * cos(t) - a.y * sin(t), a.x * sin(t) + a.y * cos(t)); }
  [[maybe_unused]] PT rotatecw(PT a, float_type t) { return PT(a.x * cos(t) + a.y * sin(t), -a.x * sin(t) + a.y * cos(t)); }
  [[maybe_unused]] float_type SQ(float_type x) { return x * x; }
  [[maybe_unused]] float_type rad_to_deg(float_type r) { return (r * 180.0 / PI); }
  [[maybe_unused]] float_type deg_to_rad(float_type d) { return (d * PI / 180.0); }

  [[maybe_unused]]
  float_type get_angle(PT a, PT b) // angle between the two vectors
  {
    float_type costheta = dot(a, b) / a.norm() / b.norm();
    return acos(max((float_type)-1.0, min((float_type)1.0, costheta)));
  }
}
using namespace Vector;

namespace Lines {
  struct line {
    PT a, b; // goes through points a and b
    PT v;
    float_type c; // line form: direction vec [cross] (x, y) = c
    line() {}

    // equation ax + by + c = 0
    line(float_type _a, float_type _b, float_type _c) : v({_b, -_a}), c(-_c)
    {
      auto p = get_points();
      a = p.first;
      b = p.second;
    }
    pair<PT, PT> get_points() { //extract any two points from this line
       PT p, q;
       double a = -v.y, b = v.x; // ax + by = c
       if (sign(a) == 0) {
         p = PT(0, c / b);
         q = PT(1, c / b);
       } else if (sign(b) == 0) {
         p = PT(c / a, 0);
         q = PT(c / a, 1);
       } else {
         p = PT(0, c / b);
         q = PT(1, (c - a) / b);
       }
       return {p, q};
    }

    // goes through points p and q
    line(PT p, PT q) : v(q - p), c(cross(v, p)), a(p), b(q) {}

    // line that is perpendicular to this and goes through point p
    line perpendicular_through(PT p) { return {p, p + perp(v)}; }
  };

  [[maybe_unused]] PT project_from_point_to_line(PT a, PT b, PT c) { return a + (b - a) * dot(c - a, b - a) / (b - a).norm2(); }
  [[maybe_unused]] PT reflection_from_point_to_line(PT a, PT b, PT c) { PT p = project_from_point_to_line(a, b, c); return p + p - c; }
  [[maybe_unused]] float_type dist_from_point_to_line(PT a, PT b, PT c) { return fabs(cross(b - a, c - a) / (b - a).norm()); }

  bool line_line_intersection(PT a, PT b, PT c, PT d, PT &ans)
  {
    float_type a1 = a.y - b.y, b1 = b.x - a.x, c1 = cross(a, b);
    float_type a2 = c.y - d.y, b2 = d.x - c.x, c2 = cross(c, d);
    float_type det = a1 * b2 - a2 * b1;
    if (det == 0) return 0;
    ans = PT((b1 * c2 - b2 * c1) / det, (c1 * a2 - a1 * c2) / det);
    return 1;
  }
}
using namespace Lines;

namespace Circles {
  struct circle {
    PT p;
    float_type r;

    circle() {}
    circle(PT _p, float_type _r) : p(_p), r(_r) {};
    circle(float_type x, float_type y, float_type _r) : p(PT(x, y)), r(_r) {};

    circle(PT a, PT b, PT c)
    {
      b = (a + b) * 0.5;
      c = (a + c) * 0.5;
      line_line_intersection(b, b + rotatecw90(a - b), c, c + rotatecw90(a - c), p);
      r = dist(a, p);
    }

    bool operator==(circle v) { return p == v.p && sign(r - v.r) == 0; }
    float_type area() { return PI * r * r; }
    float_type circumference() { return 2.0 * PI * r; }
  };

  [[maybe_unused]]
  float_type circle_circle_area(PT a, float_type r1, PT b, float_type r2)
  {
    float_type d = (a - b).norm();
    if (r1 + r2 < d + eps) return 0;
    if (r1 + d < r2 + eps) return PI * r1 * r1;
    if (r2 + d < r1 + eps) return PI * r2 * r2;
    float_type theta_1 = acos((r1 * r1 + d * d - r2 * r2) / (2 * r1 * d)),
          theta_2 = acos((r2 * r2 + d * d - r1 * r1) / (2 * r2 * d));
    return r1 * r1 * (theta_1 - sin(2 * theta_1) / 2.) + r2 * r2 * (theta_2 - sin(2 * theta_2) / 2.);
  }

  [[maybe_unused]] float_type circle_circle_area(circle a, circle b) { return circle_circle_area(a.p, a.r, b.p, b.r); }

  [[maybe_unused]]
  int tangent_lines_from_point(PT p, float_type r, PT q, line &u, line &v)
  {
    int x = sign(dist2(p, q) - r * r);
    if (x < 0) return 0; // point in circle
    if (x == 0)
    {
      u = line(q, q + rotateccw90(q - p));
      v = u;
      return 1;
    }
    float_type d = dist(p, q);
    float_type l = r * r / d;
    float_type h = sqrt(r * r - l * l);
    u = line(q, p + ((q - p).truncate(l) + (rotateccw90(q - p).truncate(h))));
    v = line(q, p + ((q - p).truncate(l) + (rotatecw90(q - p).truncate(h))));
    return 2;
  }

  [[maybe_unused]]
  int tangents_lines_from_circle(PT c1, float_type r1, PT c2, float_type r2, bool inner, line &u, line &v)
  {
    if (inner) r2 = -r2;
    PT d = c2 - c1;
    float_type dr = r1 - r2, d2 = d.norm2(), h2 = d2 - dr * dr;
    if (d2 == 0 || h2 < 0)
    {
      assert(h2 != 0);
      return 0;
    }
    vector<pair<PT, PT>> out;
    for (int tmp : {-1, 1})
    {
      PT v = (d * dr + rotateccw90(d) * sqrt(h2) * tmp) / d2;
      out.push_back({c1 + v * r1, c2 + v * r2});
    }
    u = line(out[0].first, out[0].second);
    if (out.size() == 2) v = line(out[1].first, out[1].second);
    return 1 + (h2 > 0);
  }

  [[maybe_unused]]
  vector<PT> circle_circle_intersection(PT a, float_type r, PT b, float_type R)
  {
    if (a == b && sign(r - R) == 0) return {PT(1e18, 1e18)};
    vector<PT> ret;
    float_type d = sqrt(dist2(a, b));
    if (d > r + R || d + min(r, R) < max(r, R)) return ret;
    float_type x = (d * d - R * R + r * r) / (2 * d);
    float_type y = sqrt(r * r - x * x);
    PT v = (b - a) / d;
    ret.push_back(a + v * x + rotateccw90(v) * y);
    if (y > 0) ret.push_back(a + v * x - rotateccw90(v) * y);
    return ret;
  }

  [[maybe_unused]] vector<PT> circle_circle_intersection(circle C1, circle C2)
  {
    return circle_circle_intersection(C1.p, C1.r, C2.p, C2.r);
  }

  [[maybe_unused]]
  int get_circle(PT a, PT b, float_type r, circle &c1, circle &c2)
  {
    vector<PT> v = circle_circle_intersection(a, r, b, r);
    int t = v.size();
    if (!t) return 0;
    c1.p = v[0], c1.r = r;
    if (t == 2) c2.p = v[1], c2.r = r;
    return t;
  }
}
using namespace Circles;

}


using ll = long long;
#define debug(x) #x << " = " << x << '\n'

using namespace std;

Private::circle secretc;

int no_queries = 0;
double query(double x, double y, double r) {
  no_queries++;
  return Private::circle_circle_area(secretc, Private::circle(x, y, r));
}

int main() {
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(0);

  Private::float_type X, Y, R;
  std::cin >> X >> Y >> R;

  secretc = Private::circle(X, Y, R);
  
  std::vector<double> v = findCircle();
  if ((int) v.size() != 3) {
    std::cout << "0";
    return 0;
  }
  double x, y, r;
  x = v[0];
  y = v[1];
  r = v[2];
  
  long double d = (long double) (X - x) * (X - x) + (Y - y) * (Y - y) + (R - r) * (R - r);
  int q = no_queries;

  std::cout << "D = " << std::fixed << std::setprecision(20) << d << '\n';
  std::cout << "Q = " << q << '\n';

  return 0;
}
