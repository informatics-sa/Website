#include "atena.h"
#include <vector>

using namespace std;

std::vector<double> findCircle() {
  return std::vector<double> {1, 2, 3}; // returneaza un cerc cu centrul in (1, 2) si raza 3
}
