#include <vector>

double query(double, double, double);
std::vector<double> findCircle();
